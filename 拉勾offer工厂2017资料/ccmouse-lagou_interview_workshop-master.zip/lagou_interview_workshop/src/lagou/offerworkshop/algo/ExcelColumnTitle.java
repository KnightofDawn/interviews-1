package lagou.offerworkshop.algo;

public class ExcelColumnTitle {
  public String convertToTitle(int n) {
    StringBuilder sb = new StringBuilder();
    while (n > 0) {
        n--;
        sb.append((char)('A' + (n % 26)));
        n /= 26;
    }
    return sb.reverse().toString();
  }

  public static void main(String[] args) {
    ExcelColumnTitle solver = new ExcelColumnTitle();
    System.out.println(solver.convertToTitle(1));
    System.out.println(solver.convertToTitle(2));
    System.out.println(solver.convertToTitle(3));
    System.out.println(solver.convertToTitle(25));
    System.out.println(solver.convertToTitle(26));
    System.out.println(solver.convertToTitle(27));
    System.out.println(solver.convertToTitle(28));
  }
}
