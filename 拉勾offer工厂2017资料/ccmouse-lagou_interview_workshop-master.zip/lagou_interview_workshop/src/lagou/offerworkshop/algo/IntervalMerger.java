package lagou.offerworkshop.algo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Interval {
  int start;
  int end;
  Interval() { start = 0; end = 0; }
  Interval(int s, int e) { start = s; end = e; }

  @Override
  public String toString() {
    return "[" + start + ", " + end + "]";
  }
}

public class IntervalMerger {
  public List<Interval> merge(List<Interval> intervals) {
    // (NlogN)
    intervals.sort((o1, o2) -> o1.start - o2.start);

    // O(N)
    List<Interval> results = new ArrayList<>();
    for (Interval interval : intervals) {
      if (results.isEmpty()) {
        results.add(interval);
        continue;
      }
      Interval last = results.get(results.size() - 1);
      if (interval.start > last.end) {
        results.add(interval);
      } else if (interval.end > last.end) {
        last.end = interval.end;
      }
    }
    return results;
  }

  public static void main(String[] args) {
    System.out.println(
        new IntervalMerger().merge(Arrays.asList(
            new Interval(2, 6),
            new Interval(1, 3),
            new Interval(8, 10),
            new Interval(15, 18))));
  }
}
