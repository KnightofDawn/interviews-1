package lagou.offerworkshop.algo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;

class Point {
  final int r;
  final int c;

  public Point(int r, int c) {
    this.r = r;
    this.c = c;
  }

  @Override
  public String toString() {
    return String.format("(%d, %d)", r, c);
  }
}

enum Direction {
  UP(-1, 0), LEFT(0, -1), DOWN(1, 0), RIGHT(0, 1);
  int r, c;
  private Direction(int r, int c) {
    this.r = r;
    this.c = c;
  }
}

public class MazeWalker {
  private int rows;
  private int columns;
  private int maze[][];

  public void readMaze() {
    try (Scanner in = new Scanner(
        new BufferedReader(
            new InputStreamReader(System.in)))) {
      rows = in.nextInt();
      columns = in.nextInt();
      maze = new int[rows][columns];
      for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
          maze[i][j] = in.nextInt();
        }
      }
    }
  }

  public void printMaze() {
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < columns; j++) {
        System.out.print(maze[i][j]);
      }
      System.out.println();
    }
  }

  public List<Direction> dfsWalk(
      Point start, Point finish, boolean visited[][]) {
    if (start.r < 0 || start.r >= rows
        || start.c < 0 || start.c >= columns
        || visited[start.r][start.c]
        || maze[start.r][start.c] == 1) {
      return null;
    }

    if (start.r == finish.r && start.c == finish.c) {
      return new ArrayList<>();
    }

    visited[start.r][start.c] = true;
    for (Direction direction : Direction.values()) {
      Point next = new Point(
          start.r + direction.r, start.c + direction.c);
      List<Direction> path = dfsWalk(next, finish, visited);
      if (path != null) {
        path.add(direction);
        return path;
      }
    }
    return null;
  }

  /** @return null if cannot walk, else the path */
  public List<Direction> dfsWalk(
      Point start, Point finish) {
    List<Direction> path = dfsWalk(
        start, finish, new boolean[rows][columns]);
    if (path != null) {
      Collections.reverse(path);
    }
    return path;
  }

  public boolean bfsWalk(
      Point start, Point finish,
      Direction[][] directions) {
    Queue<Point> Q = new LinkedList<>();
    Q.add(start);
    while (!Q.isEmpty()) {
      Point current = Q.poll();
      if (current.r == finish.r
          && current.c == finish.c) {
        return true;
      }

      for (Direction direction : Direction.values()) {
        Point next = new Point(
            current.r + direction.r,
            current.c + direction.c);

        if (next.r < 0 || next.r >= rows
            || next.c < 0 || next.c >= columns
            || directions[next.r][next.c] != null
            || (next.r == start.r && next.c == start.c)
            || maze[next.r][next.c] == 1) {
          continue;
        }

        directions[next.r][next.c] = direction;
        Q.add(next);
      }
    }
    return false;
  }

  /** @return null if cannot walk, else the path */
  public List<Direction> bfsWalk(
      Point start, Point finish) {
    Direction[][] directions = new Direction[rows][columns];
    if (!bfsWalk(start, finish, directions)) {
      return null;
    }

    List<Direction> path = new ArrayList<>();
    Point point = finish;
    while (point.r != start.r || point.c != start.c) {
      Direction direction = directions[point.r][point.c];
      path.add(direction);
      point = new Point(
          point.r - direction.r, point.c - direction.c);
    }
    Collections.reverse(path);
    return path;
  }

  public static void main(String[] args) {
    MazeWalker mazeWalker = new MazeWalker();
    mazeWalker.readMaze();
    mazeWalker.printMaze();
    List<Direction> path;
    path = mazeWalker.bfsWalk(
        new Point(0, 0), new Point(4, 0));
    printPath("BFS (0,0) - (4,0)", path);
    path = mazeWalker.dfsWalk(
        new Point(0, 0), new Point(4, 0));
    printPath("DFS (0,0) - (4,0)", path);
    path = mazeWalker.bfsWalk(
        new Point(0, 0), new Point(2, 2));
    printPath("BFS (0,0) - (2,2)", path);
    path = mazeWalker.dfsWalk(
        new Point(0, 0), new Point(2, 2));
    printPath("DFS (0,0) - (2,2)", path);
    path = mazeWalker.bfsWalk(
        new Point(0, 0), new Point(0, 0));
    printPath("BFS (0,0) - (0,0)", path);
    path = mazeWalker.dfsWalk(
        new Point(0, 0), new Point(0, 0));
    printPath("DFS (0,0) - (0,0)", path);
  }

  private static void printPath(
      String title, List<Direction> path) {
    System.out.println(title);
    if (path == null) {
      System.out.println("Cannot walk.");
    } else {
      for (Direction direction : path) {
        System.out.println(direction);
      }
    }
    System.out.println();
  }
}
