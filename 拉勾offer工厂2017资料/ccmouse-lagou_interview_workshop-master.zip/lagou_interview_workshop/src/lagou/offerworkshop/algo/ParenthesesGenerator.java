package lagou.offerworkshop.algo;

import java.util.ArrayList;
import java.util.List;

// See python version for alternate solution
public class ParenthesesGenerator {
  private void generateParenthesis(String prefix,
      int leftRemaining, int rightRemaining,
      List<String> results) {
    if (leftRemaining == 0 && rightRemaining == 0) {
      results.add(prefix);
      return;
    }

    if (leftRemaining > 0) {
      generateParenthesis(
          prefix + '(',
          leftRemaining - 1, rightRemaining, results);
    }
    if (rightRemaining > 0 && leftRemaining < rightRemaining) {
      generateParenthesis(
          prefix + ')',
          leftRemaining, rightRemaining - 1, results);
    }
  }

  public List<String> generateParenthesis(int n) {
    ArrayList<String> results = new ArrayList<>();
    generateParenthesis("", n, n, results);
    return results;
  }

  public static void main(String[] args) {
    new ParenthesesGenerator().generateParenthesis(3);
  }
}
