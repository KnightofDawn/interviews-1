package lagou.offerworkshop.algo;

public class RainWater {
  public int trap(int[] height) {
    int total = 0;
    int maxi = 0;
    int currentMax = 0;
    int currentTrapped = 0;
    for (int i = 0; i < height.length; i++) {
      if (height[i] >= currentMax) {
        total += currentTrapped;
        currentTrapped = 0;
        currentMax = height[i];
        maxi = i;
      } else {
        currentTrapped += currentMax - height[i];
      }
    }

    currentMax = 0;
    currentTrapped = 0;
    for (int i = height.length - 1; i >= maxi; i--) {
      if (height[i] >= currentMax) {
        total += currentTrapped;
        currentTrapped = 0;
        currentMax = height[i];
      } else {
        currentTrapped += currentMax - height[i];
      }
    }

    return total;
  }

  public static void main(String[] args) {
    RainWater rainWater = new RainWater();
    System.out.println(rainWater.trap(
        new int[]{0,1,0,2,1,0,1,3,2,1,2,1}));
    System.out.println(rainWater.trap(
        new int[]{0,1,2,3,4,5}));
    System.out.println(rainWater.trap(
        new int[]{0,1,2,5,4,5}));
    System.out.println(rainWater.trap(
        new int[]{}));
  }
}
