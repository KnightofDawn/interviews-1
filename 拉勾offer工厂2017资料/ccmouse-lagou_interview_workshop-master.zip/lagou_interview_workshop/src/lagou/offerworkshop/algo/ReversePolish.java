package lagou.offerworkshop.algo;

import java.util.Stack;

public class ReversePolish {
  public int evalRPN(String[] tokens) {
    Stack<Integer> s = new Stack<>();
    for (String token : tokens) {
      switch (token) {
      case "+":
        s.push(s.pop() + s.pop());
        break;
      case "-":
        s.push(-s.pop() + s.pop());
        break;
      case "*":
        s.push(s.pop() * s.pop());
        break;
      case "/":
        int b = s.pop();
        int a = s.pop();
        s.push(a / b);
        break;
      default:
        s.push(Integer.valueOf(token));
        break;
      }
    }
    return s.pop();
  }

  public static void main(String[] args) {
    ReversePolish expr = new ReversePolish();
    System.out.println(
        expr.evalRPN(new String[]{"4", "13", "5", "/", "+"}));
  }
}
