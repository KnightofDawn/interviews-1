package lagou.offerworkshop.algo;

import java.util.HashMap;
import java.util.Map;

public class SubstringWithoutRepeat {
  public int lengthOfLongestSubstring(String s) {
    Map<Character, Integer> pos = new HashMap<>();
    int maxLength = 0;
    int start = 0;
    for (int end = 0; end < s.length(); end++) {
      char ch = s.charAt(end);
      Integer seenPos = pos.get(ch);
      if (seenPos != null && seenPos >= start) {
        maxLength = Math.max(maxLength, end - start);
        start = seenPos + 1;
      }
      pos.put(ch, end);
    }

    return Math.max(maxLength, s.length() - start);
  }

  public static void main(String[] args) {
    SubstringWithoutRepeat solver =
        new SubstringWithoutRepeat();
    System.out.println(
        solver.lengthOfLongestSubstring("abcabcbb"));
    System.out.println(
        solver.lengthOfLongestSubstring("bbbbb"));
    System.out.println(
        solver.lengthOfLongestSubstring("pwwkew"));
    System.out.println(
        solver.lengthOfLongestSubstring(""));
  }
}
