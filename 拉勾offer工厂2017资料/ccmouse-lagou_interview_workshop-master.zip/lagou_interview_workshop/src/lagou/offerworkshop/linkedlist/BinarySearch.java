package lagou.offerworkshop.linkedlist;

public class BinarySearch {
  public int binarySearch(int[] values, int key) {
    int a = 0;
    int b = values.length;

    // key may only be in [a, b)
    while(a < b) {
      int m = a + (b - a) / 2;
      if (values[m] == key) {
        return m;
      } else if (key < values[m]) {
        b = m;
      } else { // key > values[m]
        a = m + 1;
      }
    }
    return -1;
  }

  public static void main(String[] args) {
    BinarySearch bs = new BinarySearch();
    System.out.println(bs.binarySearch(
        new int[]{1, 2, 10, 15, 100}, 15));
    System.out.println(bs.binarySearch(
        new int[]{}, 15));
    System.out.println(bs.binarySearch(
        new int[]{1}, 15));
    System.out.println(bs.binarySearch(
        new int[]{1}, 1));
    System.out.println(bs.binarySearch(
        new int[]{1, 2, 10, 15, 100}, 13));
    System.out.println(bs.binarySearch(
        new int[]{1, 2, 10, 15, 100}, -1));
    System.out.println(bs.binarySearch(
        new int[]{1, 2, 10, 15, 100}, 100));
    System.out.println(bs.binarySearch(
        new int[]{1, 2, 10, 15, 100}, 101));
  }
}
