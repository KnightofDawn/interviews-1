package lagou.offerworkshop.linkedlist;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LinkedListCreator {

  public Node createLinkedList(List<Integer> values) {
    if (values.isEmpty()) {
      return null;
    }

    Node next = createLinkedList(
        values.subList(1, values.size()));
    Node head = new Node(values.get(0));
    head.setNext(next);
    return head;
  }



  public static void main(String[] args) {
    LinkedListCreator creator = new LinkedListCreator();

    Node.printLinkedList(creator.createLinkedList(
        Arrays.asList(1, 2, 3, 4, 5)));
    Node.printLinkedList(creator.createLinkedList(
        new ArrayList<>()));
    Node.printLinkedList(creator.createLinkedList(
        Arrays.asList(1)));
  }

}
