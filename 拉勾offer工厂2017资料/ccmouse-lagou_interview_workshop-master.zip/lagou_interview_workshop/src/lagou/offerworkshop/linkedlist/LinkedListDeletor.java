package lagou.offerworkshop.linkedlist;

import java.util.Arrays;

public class LinkedListDeletor {
  public Node deleteIf(Node head, int key) {
    while (head != null && head.getValue() == key) {
      head = head.getNext();
    }

    if (head == null) {
      return null;
    }

    Node prev = head;
    while (prev.getNext() != null) {
      if (prev.getNext().getValue() == key) {
        prev.setNext(prev.getNext().getNext());
      } else {
        prev = prev.getNext();
      }
    }

    return head;
  }

  public static void main(String[] args) {
    LinkedListCreator creator = new LinkedListCreator();
    LinkedListDeletor deletor = new LinkedListDeletor();
    Node.printLinkedList(deletor.deleteIf(
        creator.createLinkedList(
            Arrays.asList(1, 2, 3, 4, 5)), 2));
    Node.printLinkedList(deletor.deleteIf(
        creator.createLinkedList(
            Arrays.asList(1, 2, 3, 2, 5)), 2));
    Node.printLinkedList(deletor.deleteIf(
        creator.createLinkedList(
            Arrays.asList(1, 2, 3, 2, 2)), 2));
    Node.printLinkedList(deletor.deleteIf(
        creator.createLinkedList(
            Arrays.asList(2, 2, 3, 2, 2)), 2));
    Node.printLinkedList(deletor.deleteIf(
        creator.createLinkedList(
            Arrays.asList(2, 2, 2, 2, 2)), 2));
  }
}
