package lagou.offerworkshop.linkedlist;

import java.util.ArrayList;
import java.util.Arrays;

public class LinkedListReversal {
  public Node reverseLinkedList(Node head) {
    if (head == null || head.getNext() == null) {
      return head;
    }

    Node newHead = reverseLinkedList(head.getNext());
    head.getNext().setNext(head);
    head.setNext(null);
    return newHead;
  }

  public Node reverseNonRecursive(Node head) {
    Node newHead = null;
    Node currentHead = head;

    while (currentHead != null) {
      Node next = currentHead.getNext();
      currentHead.setNext(newHead);
      newHead = currentHead;
      currentHead = next;
    }

    return newHead;
  }

  public static void main(String[] args) {
    LinkedListCreator creator = new LinkedListCreator();
    LinkedListReversal rev = new LinkedListReversal();
    Node.printLinkedList(rev.reverseNonRecursive(
        creator.createLinkedList(
            Arrays.asList(1, 2, 3, 4, 5))));
    Node.printLinkedList(rev.reverseNonRecursive(
        creator.createLinkedList(
            new ArrayList<>())));
    Node.printLinkedList(rev.reverseNonRecursive(
        creator.createLinkedList(
            Arrays.asList(1))));
  }
}
