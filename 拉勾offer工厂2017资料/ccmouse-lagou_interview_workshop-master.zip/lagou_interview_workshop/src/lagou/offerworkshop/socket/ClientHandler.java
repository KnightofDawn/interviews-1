package lagou.offerworkshop.socket;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ClientHandler implements Runnable {
  private final Socket client;
  private final RequestHandler handler;

  public ClientHandler(Socket client, RequestHandler handler) {
    this.client = client;
    this.handler = handler;
  }

  @Override
  public void run() {
    try (
        Scanner in = new Scanner(client.getInputStream());
        PrintWriter out =
            new PrintWriter(client.getOutputStream());
        Socket managedClient = client) {
      String str;
      while (!(str = in.nextLine()).equals("quit")) {
        System.out.println(
            String.format("Received from %s: %s",
                managedClient.getRemoteSocketAddress(), str));
        out.print(handler.handleRequest(str));
        out.flush();
      }
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }
}
