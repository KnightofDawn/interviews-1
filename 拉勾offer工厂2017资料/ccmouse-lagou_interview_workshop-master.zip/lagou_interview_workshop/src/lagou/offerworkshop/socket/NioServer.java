package lagou.offerworkshop.socket;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class NioServer {

  public static void main(String[] args) throws IOException {
    ServerSocketChannel serverSocket =
        ServerSocketChannel.open();
    serverSocket.configureBlocking(false);
    serverSocket.bind(new InetSocketAddress(7777));
    System.out.println("Listening on "
        + serverSocket.getLocalAddress());

    Selector selector = Selector.open();
    serverSocket.register(selector, SelectionKey.OP_ACCEPT);

    ByteBuffer buffer = ByteBuffer.allocate(1024);
    RequestHandler handler = new RequestHandler();
    while (true) {
      int selected = selector.select(); // blocking only here
      if (selected == 0) {
        continue;
      }

      Set<SelectionKey> keys = selector.selectedKeys();
      Iterator<SelectionKey> iterator = keys.iterator();
      while (iterator.hasNext()) {
        SelectionKey key = iterator.next();
        if (key.isAcceptable()) {
          SocketChannel clientChannel = serverSocket.accept();
          if (clientChannel != null) {
            clientChannel.configureBlocking(false);
            clientChannel.register(selector, SelectionKey.OP_READ);
          }
        }

        if (key.isReadable()) {
          SocketChannel channel = (SocketChannel) key.channel();
          int bytesRead = channel.read(buffer);
          String request = new String(buffer.array()).trim();
          buffer.clear();
          System.out.println(String.format(
              "Read %d bytes: %s", bytesRead, request));

          if (request.equals("quit")) {
            closeAndUnregister(key);
          } else {
            channel.write(ByteBuffer.wrap(
                handler.handleRequest(request).getBytes()));
          }
        }
        iterator.remove();
      }
    }
  }

  private static void closeAndUnregister(SelectionKey key)
      throws IOException {
    try (Channel channel = key.channel()) {
      key.cancel();
    }
  }
}
