package lagou.offerworkshop.socket;

public class RequestHandler {
  String handleRequest(String request) {
    return "Hello " + request + "\n";
  }
}
