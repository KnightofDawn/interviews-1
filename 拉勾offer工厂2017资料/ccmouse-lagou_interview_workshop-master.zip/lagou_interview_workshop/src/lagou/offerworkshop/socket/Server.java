package lagou.offerworkshop.socket;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {

  public static void main(String[] args) throws IOException {
    RequestHandler handler = new RequestHandler();
    ExecutorService executor =
        Executors.newFixedThreadPool(2);
    try (ServerSocket serverSocket =
        new ServerSocket(6666)) {
      System.out.println("Listening on "
              + serverSocket.getLocalSocketAddress());
      while (true) {
        Socket client = serverSocket.accept();
        executor.submit(
            new ClientHandler(client, handler));
      }
    }
  }
}
