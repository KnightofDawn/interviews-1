def generate(n):
    if n == 0:
        yield ""
        return
    # generate like: (...left...)...right...
    for left in range(n):
        for leftResult in generate(left):
            for rightResult in generate(n - 1 - left):
                yield "(" + leftResult + ")" + rightResult

# 1. Try learn the "yield" keyword in python. It breaks
#    a function in the middle with all states saved!
# 2. How many results are there in generate(100)? 
#    Hint: Catalan number
# 3. Why can we start printing results instantly? 
#    Can we solve the problem using the same algorithm 
#    in Java, c++, and equally simple?
for result in generate(100):
    print(result)
