def logged(func):
    def wrapper(*args, **kwargs):
        print("Calling {} with args {} {}".format(
            func.__name__, args, kwargs))
        return func(*args, **kwargs)
    return wrapper

@logged
def add(a, b):
    return a + b

@logged
def greeting(msg = "Hello", name = "John"):
    return msg + " " + name + "."

print(add(1, 3))
print(greeting(msg = "Hi", name = "Mary"))
