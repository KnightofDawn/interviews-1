def fibonacci_generator():
    a, b = 0, 1
    def generator():
        nonlocal a, b
        a, b = b, a + b
        return a
    return generator
    
f = fibonacci_generator()

print(f())
print(f())
print(f())
print(f())
print(f())
print(f())
print(f())
print(f())
print(f())
print(f())
print(f())
